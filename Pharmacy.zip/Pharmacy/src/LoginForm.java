import SQLOperation.DatabaseFetcher;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.regex.*;
public class LoginForm extends JFrame{

    Container container = getContentPane();
    JLabel Rbk;
    JLabel Lbk;
    ImageIcon iconUser=new ImageIcon("Media/userName.png");
    ImageIcon iconPassword=new ImageIcon("Media/password.png");
    JLabel userLabel = new JLabel(iconUser);
    JLabel Elogin = new JLabel("Email");
    JLabel Plogin = new JLabel("Password");

    JLabel passwordLabel = new JLabel(iconPassword);
    JTextField userField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JButton loginButton = new JButton("LOGIN");
    JButton resetButton = new JButton("RESET");
    JCheckBox showPassword = new JCheckBox("Show Password");
    JCheckBox Employee = new JCheckBox("Employee");
    JCheckBox Client = new JCheckBox("Client");

    
    //constructor
    public LoginForm() {
        setTitle("Login");
        setLocationRelativeTo(this);
         setSize(600,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        //label fontColor
        Elogin.setForeground(Color.WHITE);
        Plogin.setForeground(Color.WHITE);


        container.add(Employee);
        container.add(Client);
        //background for each site
        Rbk=new JLabel("", new ImageIcon("Media/r.png"),JLabel.CENTER);
        Rbk.setBounds(120,0,820,390);

        Lbk=new JLabel("", new ImageIcon("Media/l.png"),JLabel.CENTER);
        Lbk.setBounds(-265,-10,800,390);
        addComponentsToContainer();


        //Functios to set layout and add in compunnint

        setLayoutManager();
        setLocationAndSize();
        setVisible(true);





        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            ResultSet resultSet = null;
            //chek on database   with try & catch
                if (Client.isSelected() && !Employee.isSelected())
                {
                    String query = "SELECT * FROM client";

                   try {
                       DatabaseFetcher.select(query);
                   } catch (SQLException ex) {
                       JOptionPane.showMessageDialog(container , ex.getMessage(),ex.getMessage(),JOptionPane.INFORMATION_MESSAGE);
                   }

                    try {
                        if (isValidEmail(resultSet.getString("ClientEmail")) && resultSet.getString("ClientPassword").equals(passwordField.getPassword().toString())) {
                            JOptionPane.showMessageDialog(container , "Login Successful","Logging",JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(container, "Invalid Username or Password","ERROR",JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }




                } else if (!Client.isSelected() && Employee.isSelected()) {
                    String query = "select * from employee\r where EmpEmail = "+userField.getText()+';';
                    try {
                        DatabaseFetcher.select(query);
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(container , ex.getMessage(),ex.getMessage(),JOptionPane.INFORMATION_MESSAGE);
                    }

                    try {
                        if (isValidEmail(resultSet.getString("EmpEmail")) ) {
                            JOptionPane.showMessageDialog(container , "Login Successful","Logging",JOptionPane.INFORMATION_MESSAGE);
                        } else {

                            JOptionPane.showMessageDialog(container, "Invalid Username or Password","ERROR",JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }


                }
                else {
                    JOptionPane.showMessageDialog(container,"Please confirm your status (Client or Employee)","Invalid choice",JOptionPane.ERROR_MESSAGE);
                }





            }
        });



        showPassword.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            if (showPassword.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('*');
            }
            }
        });


        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                userField.setText("");
                passwordField.setText("");
                }
            });

            }

    public void setLayoutManager() {
        container.setLayout(null);

    }

    public void setLocationAndSize() {
        userLabel.setBounds(300, 50, 100, 50);
        Elogin.setBounds(400, 30, 180, 50);
        Plogin.setBounds(400, 100, 180, 50);
        passwordLabel.setBounds(300, 130, 100, 60);
        userField.setBounds(400, 70, 150, 30);
        passwordField.setBounds(400, 140, 150, 30);
        showPassword.setBounds(400, 200, 150, 30);
        Employee.setBounds(330,250,100,30);
        Client.setBounds(460,250,100,30);
        loginButton.setBounds(330, 285, 100, 30);
        resetButton.setBounds(460, 285, 100, 30);
    }

    public void addComponentsToContainer() {
        container.add(userLabel);
        container.add(passwordLabel);
        container.add(userField);
        container.add(passwordField);
        container.add(showPassword);
        container.add(loginButton);
        container.add(resetButton);
        container.add(Elogin);
        container.add(Plogin);
        container.add(Rbk);
        container.add(Lbk);
    }



    public boolean isValidEmail(String email) {
//        Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("\\\\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\\\\.)+(com|net)\\\\b");
//        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(email);

        String pattern = "\\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\\.)+(com|net)\\b";
        Pattern emailPattern = Pattern.compile(pattern);
        Matcher matcher = emailPattern.matcher(email);
        return matcher.matches();

    }
}

