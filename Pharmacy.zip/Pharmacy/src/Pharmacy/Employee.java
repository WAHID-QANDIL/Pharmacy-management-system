package Pharmacy;
public class Employee extends Human {
    private String Email;
    private String Password;

    public void setEmail(String email) {
        Email = email;
    }
    public void setPassword(String password) {
        Password = password;
    }
    public String getEmail() {
        return Email;
    }
    public String getPassword() {
        return Password;
    }
    public Employee(String name, String location, String identificationNumber, String gender, int age, String email, String password) {
        super(name, location, identificationNumber, gender, age);
        Email = email;
        Password = password;
    }
}
