package Pharmacy;

import java.sql.Date;
import java.sql.Time;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

public class Order {
    private String Name;
    private Date date;
    private Time Time;
    private double TotalPrice;
    private List<Product> Products; //Uninitialized ArrayList
    public Order()
    {

    }


}
