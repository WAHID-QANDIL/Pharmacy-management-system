package SQLOperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public abstract class DatabaseModifier{
    static Connection connection;

    static {
        try {
            connection = DatabaseConnector.connect();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void modify(String query) {
        try {
            PreparedStatement statement =(PreparedStatement) connection.createStatement();
            statement.executeQuery(query);
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e.getMessage(),e.getCause());
        }
    }
}
