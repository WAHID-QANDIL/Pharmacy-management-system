package SQLOperation;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class DatabaseFetcher {
    public static ResultSet select(String query) throws SQLException {
        Connection connection = DatabaseConnector.connect();
        try {
           PreparedStatement statement = connection.prepareStatement(query);
           return statement.executeQuery();
       }catch (SQLException e) {
           throw new RuntimeException(e.getMessage(),new Throwable(e.getCause()));
       }
    }
}
