package DataValidation;

public interface isEmail{
    boolean is_Email();
}
