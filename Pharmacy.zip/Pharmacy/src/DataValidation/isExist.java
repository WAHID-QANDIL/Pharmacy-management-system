package DataValidation;

public interface isExist {
    boolean is_Exists();
}
