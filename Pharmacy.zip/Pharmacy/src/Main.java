import SQLOperation.DatabaseFetcher;
import SQLOperation.DatabaseModifier;

import java.io.IOException;
import java.lang.*;
import java.sql.*;

public class  Main {
    public static void main(String[] args) throws RuntimeException, SQLException, IOException {
//        final String url = "jdbc:mysql://localhost:3306/Pharmacy";
//        String user = "root";
//        String password = "Y123!";
//        String sql = "select * from pharmacy";
//        Client client = new Client();
//        System.out.println("Main");

        new LoginForm();
//        String q = "";
//        DatabaseModifier.modify(q);
//        ResultSet resultSet = DatabaseFetcher.select(q);



    }
}